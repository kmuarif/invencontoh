<style type=text/css>
*{
font-family: Arial;
font-size: 12px;
margin:0px;
padding:0px;
}
@page {
 margin-left:3cm 2cm 2cm 2cm;
}
.container{
    margin-top: 10px;
    width: 780px;
    margin-left: auto;
    margin-right: auto;
}
table.grid{
width:20.4cm ;
font-size: 9pt;
border-collapse:collapse;
}
table.grid th{
padding-top:1mm;
padding-bottom:1mm;
}
table.grid th{
background: #F0F0F0;
border: 0.2mm solid #000;
text-align:center;
padding-left:0.2cm;
}
table.grid tr td{
padding-top:0.5mm;
padding-bottom:0.5mm;
padding-left:2mm;
border:0.2mm solid #000;
}
h1{
font-size: 18pt;
}
h2{
font-size: 14pt;
}
h3{
font-size: 10pt;
}
.header{
display: block;
width:20.4cm ;
margin-bottom: 0.3cm;
text-align: center;
margin-top: 10px;
}
.attr{
font-size:9pt;
width: 100%;
padding-top:2pt;
padding-bottom:2pt;
border-top: 0.2mm solid #000;
border-bottom: 0.2mm solid #000;
}
.pagebreak {
width:20cm ;
page-break-after: always;
margin-bottom:10px;
}
.akhir {
width:20cm ;
}
.page {
font-size:13px;
padding-top: 20px;
}
.footer{
    padding-top: 20px;
    margin-left: 480px;
}
</style>

<link rel="shortcut icon" href="../img/grobogan-ico-2.png">
<title>Inventarisku</title>
<?php

include '../config/Class_Dataall.php';
include '../config/config.php';
include "../phpqrcode/qrlib.php";
$db = new Class_Dataall();
                 $tempdir = "qrcode-img/";        // Nama folder untuk pemyimpanan file qrcode
        
                  if (!file_exists($tempdir)) {       //jika folder belum ada, maka buat
                  mkdir($tempdir); }
session_start();

?>
<div class='header' align='center'>
                                                  
                  <!--  <p align='right'>printed by diskominfo </p></br> -->
                    <h2 align='center'>DAFTAR INVENTARISASI DOMAIN DAN SUBDOMAIN WEBSITE di LINGKUNGAN PEMERINTAH KABUPATEN GROBOGAN</h2>
                    <br>
                    <?php
                    
                    $username = $_SESSION["username"];
   
       
                    $sql = "select * from tbl_useropd WHERE username = '$username'";
                    $data = mysqli_query($conn,$sql);
                    $row = mysqli_fetch_array($data);  
                    $data1=$row["kode_opd"];
                    $sql1 = "select * from tbl_opd WHERE kode_opd = '$data1'";
                    $data2 = mysqli_query($conn,$sql1);
                    $row2 = mysqli_fetch_array($data2);
                    $teks_qrcode_link    ="https://inventarisku.diskominfo.grobogan.go.id/";
                    $namafile            ="qrcode-web.png";
                    $quality             ="H"; // ini ada 4 pilihan yaitu L (Low), M(Medium), Q(Good), H(High)
                    $ukuran              =5; // 1 adalah yang terkecil, 10 paling besar
                    $padding             =1;
                  
                    QRCode::png($teks_qrcode_link, $tempdir.$namafile, $quality, $ukuran, $padding);
                    ?> 

     

                    <div >
                    <img src="../dataall/qrcode-img/qrcode-web.png" alt="Stickman" width="50" height="50" align="right" style='margin-top:-15px; margin-right:0px'>
                    
                    <p align='left'>Instansi : <?=$row2["nama_opd"];?>
                    
                     
                    </p>


                    </div>
                    
                    <br/><br/><br/>
                <!--<h2>Cetak Data Domain</h2>-->
            </div>
        <table class='grid' align='center'>
        <tr>
            <th width='5%'>No</th>
            <th>Nama Domain</th>
            <th>Status Aktif</th>
            <th>Keterangan</th>
        </tr>
    <div class='container' align='center'>
                <?php 
                $date = date("d F Y");
                $tz = 'Asia/Jakarta';
                        $dt = new DateTime("now", new DateTimeZone($tz));
                        //$timestamp = $dt->format('G:i:s');
                        $timestamp1 = $dt->format('d F Y');
                $no= 1;
                foreach ($db->tampil_data_print() as $row) {
                 ?>
        <tr>
                <td align='center'><?=$no++?></td>
                <td align='left'><?=$row['nama_domain']?></td>
                <!-- <td align='center'><?//=$row['status_aktif']?></td> -->
                <td style='display:none' align='center'><?=$row['status_aktif'];
                            $status=$row['status_aktif'];
                        
                        if($status=='1')
                        {
                            echo " <td style='display:block'align='center'> YA </td>";
                        } else{
                            echo "<td style='display:block'align='center'> TIDAK </td>";
                        }
                        
                        
                        ?>
                    
                    
                        </td>

                <td align='left'><?=$row['ket']?></td>
                
                
        </tr>
        <?php } ?>
    </table>

        
    <div class='footer'>
            <div align='center'>Grobogan, <?=$timestamp1?></div>
            <div align='center'> Penanggungjawab</div>
            <!-- <div style='margin-top:90px; margin-right:5px;'><?=$_SESSION['username']?></div> --->
            <?php
            $username = $_SESSION["username"];
   
       
                    $sql = "select * from tbl_useropd WHERE username = '$username'";
                    $data = mysqli_query($conn,$sql);
                    $row = mysqli_fetch_array($data);  
                   $isi=$row["nama_user"]."_".$row["nip_user"];
                  
                  
                  
                  // berikut adalah parameter qr code
                  $teks_qrcode    =$isi;
                  
                  $namafile        ="$username.qrcode-1.png";
                  $quality        ="H"; // ini ada 4 pilihan yaitu L (Low), M(Medium), Q(Good), H(High)
                  $ukuran            =5; // 1 adalah yang terkecil, 10 paling besar
                  $padding        =1;
                  
                  QRCode::png($teks_qrcode, $tempdir.$namafile, $quality, $ukuran, $padding);


            ?>
            <div style='margin-top:5px;' align='center'><img src="../dataall/qrcode-img/<?=$namafile;?>" alt="qrcode" width="60" height="60" > </div> 
            <div style='margin-top:2px;'align='center'><u><?=$row["nama_user"];?></u></div>
            <div style='margin-top:1px;'align='center'>NIP : <?=$row["nip_user"];?></div>
            <br>
        </div>
    <!-- <div class='page' align='center'>Hal - .$page.</div>; -->
                                                        
                <div > <?php
                        $tz = 'Asia/Jakarta';
                        $dt = new DateTime("now", new DateTimeZone($tz));
                        $timestamp = $dt->format('G:i:s');
                        $timestamp1 = $dt->format('d F Y'); 
                        $timestamp2=$timestamp." WIB ".$timestamp1;
                        ?>
                    <hr></hr><p align='center'>
                <span ><strong> <em>printed on  <?php echo " $timestamp WIB ";?></em>-<i> powered by Diskominfo Kab. Grobogan</i></strong></span>
                </p>
                <hr style='margin-top:2px;'></hr>
                </div>
                                                     <!--   <div >
                                                        <span hidden id="counter">0.1</span>
                                                        </div>
                                                    -->
    </div>
    
</script>
<script type=text/javascript>
    window.print();
    
</script>

<script type="text/javascript">
        var i=100;
        var interval=setInterval(function(){
           
            if(i<=0){
                window.close();
                clearInterval(interval);
            }
            i--;
        }, 500);


</script>


<script type="text/javascript">
function countdown() {
 var i = document.getElementById('counter');
 i.innerHTML = parseInt(i.innerHTML)-1;
if (parseInt(i.innerHTML)<=0) {
 window.close();
 }
}

setInterval(function(){ countdown(); },300);
</script>
