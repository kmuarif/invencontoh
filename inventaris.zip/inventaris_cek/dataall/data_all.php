<div class="row">
    <div class="col-lg-12">
        <div class="page-header">
            <h1>Semua Data Domain</h1>
        <div class="text-right" style="margin-top: -4%;">
            <a href="dataall/cetak_data_all.php" target="_blank" class="btn btn-default " style=""><i class="fa fa-print "></i> Print </a>
        </div>
        </div>

    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
               <?php  
              $username = $_SESSION["username"];
   
       
            $sql = "select * from tbl_useropd WHERE username = '$username'";
            $data = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($data);  
            $data1=$row["kode_opd"];
            $sql1 = "select * from tbl_opd WHERE kode_opd = '$data1'";
            $data2 = mysqli_query($conn,$sql1);
            $row2 = mysqli_fetch_array($data2);
            ?> 

       Instansi : <?=$row2["nama_opd"];?>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" cellpadding="0" cellspacing="0" id="dataTables-example">
                    <thead>
    <?php
    ?>
                        <tr>
                            <th>No</th>
                            <th>Nama Domain</th>
                            <th>Status Aktif</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php 
     $no = 1;
    
    if (is_array($st->tampil_data_print()) && count($st->tampil_data_print()) > 0) {
        
    foreach ($st->tampil_data_print() as $row) {

     ?>
                    <tr>
                       <td><?=$no++?></td>
                        <td><?=$row['nama_domain']?></td>
                        <td style='display:none'><?=$row['status_aktif'];
                            $status=$row['status_aktif'];
                        
                        if($status=='1')
                        {
                            echo " <td style='display:block'> YA </td>";
                        } else{
                            echo "<td style='display:block'> TIDAK </td>";
                        }
                        
                        
                        ?>
                    
                    
                        </td>
                        <td><?=$row['ket']?></td>
                        
                    </tr>
    <?php } 
}?>
                    </tbody>
                </table>
                <!-- /.table-responsive -->
               
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->