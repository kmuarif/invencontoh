<?php 
session_start();
if (!isset($_SESSION["username"])) {

echo "<script>window.location.href='login.php';</script>";
exit();
}

 $timeout = 1; // setting timeout dalam menit
	$logout = "login.php"; // redirect halaman logout

	$timeout = $timeout * 300; // menit ke detik
	if(isset($_SESSION['start_session'])){
		$elapsed_time = time()-$_SESSION['start_session'];
		if($elapsed_time >= $timeout){
			session_destroy();
			echo "<script type='text/javascript'>alert('Kakak Diam Terlalu Lama, Silahkan Login Lagi');window.location='$logout'</script>";
		}
	}

	$_SESSION['start_session']=time(); 
?>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">APLIKASI INVENTARISASI DOMAIN</a>
    </div>
    <!-- /.navbar-header -->
    <?php     
        
        $username = $_SESSION["username"];

                        $date = date("h:i:s A d F Y"); 
                        $tz = 'Asia/Jakarta';
                        $dt = new DateTime("now", new DateTimeZone($tz));
                        $timestamp = $dt->format('G:i:s');
                        $timestamp1 = $dt->format('d F Y');
                        $timestamp2=$timestamp." WIB ".$timestamp1;
                        $sqlupdatedlogin = "update tbl_useropd set last_login='$timestamp2' WHERE username = '$username'";
                        $dataupdated = mysqli_query($conn,$sqlupdatedlogin);










    // echo $username;
       // $sql = "select * from tbl_useropd WHERE username = '.$username.'";
        $sql = "select * from tbl_useropd WHERE username = '$username'";
        // echo $sql;
        $data = mysqli_query($conn,$sql);

        $row = mysqli_fetch_array($data);
        // var_dump($row);
        ?>

    <ul class="nav navbar-top-links navbar-right">
        <!-- /.dropdown -->
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                 <span class="text-uppercase"><?=$row["nama_user"]?></span> - <span class="text-uppercase"><?=$row["nip_user"]?></span> : <span class="text-uppercase"><?=$_SESSION["username"]?></span>
                 
                 <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <!-- <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>&nbsp;&nbsp;&nbsp;<span class="text-uppercase"><?//=$_SESSION["username"]?></span>
                -->
            </a>
            <ul class="dropdown-menu dropdown-user">
                <li><a href="index.php?page=profile"><i class="fa fa-user fa-fw"></i>Profile</a>
                </li>
                <li><a href="index.php?page=pengaturan"><i class="fa fa-gear fa-fw"></i> Pengaturan</a>
                </li>
                <li class="divider"></li>
                <li><a href="logout.php" onclick="return confirm('Yakin keluar?');"><i class="fa fa-sign-out fa-fw"></i> Keluar</a>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
        <!-- /.dropdown -->
    </ul>
</nav>