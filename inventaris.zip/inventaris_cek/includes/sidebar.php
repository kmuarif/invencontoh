<?php
if (($_SESSION["akses_level"])=='1')
{ 
    //echo ($_SESSION["akses_level"]);
    ?>
    <div class="navbar-default sidebar" role="navigation">
<div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
        
        <li>
            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
        </li>
        <li>
            <a href="index.php?page=datadomain"><i class="fa fa-qrcode fa-fw"></i> Domain dan Subdomain<span class="fa arrow"></span></a>
          
        </li>
        <li>
            <a href="#"><i class="fa fa-sign-in fa-fw"></i> Pengelolaan Domain<span class="fa arrow"></span></a>
            <ul class="nav nav-second-level">
                <li>
                    <a href="index.php?page=inputdomain"><i class="fa fa-angle-right fa-fw"></i>Tambah Verifikasi</a>
                </li>
            </ul>
            <!-- /.nav-second-level -->
        </li>
        <li>
            <a href="index.php?page=datastok"><i class="fa fa-truck fa-fw"></i>Data Status Domain</a>
        </li>
        <li>
            <a href="#"><i class="fa fa-th-list fa-users"></i> User Management <span class="fa arrow"></span></a>
            <ul class="nav nav-second-level">
                <li>
                    <a href="supplier.php"><i class="fa fa-angle-right fa-fw"></i>Data User</a>
                </li>
                <li>
                    <a href="supplier.php?page=supplierbaru"><i class="fa fa-angle-right fa-fw"></i>Tambah User</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="index.php?page=pengaturan"><i class="fa fa-wrench fa-fw"></i> Pengaturan</a>
        </li>
    </ul>
</div>
</div>


<?php
}else{
?><div class="navbar-default sidebar" role="navigation">
<div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
        
        <li>
            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
        </li>
        <li>
            <a href="index.php?page=datadomain"><i class="fa fa-qrcode fa-fw"></i> Domain dan Subdomain<span class="fa arrow"></span></a>
          
        </li>
        <li>
           <a href="index.php?page=dataall"><i class="fa fa-truck fa-fw"></i>Data Status Domain</a> 
        </li>
        
        <li>
            <a href="index.php?page=pengaturan"><i class="fa fa-wrench fa-fw"></i> Pengaturan</a>
        </li>
    </ul>
</div>
</div>

<?php
} ?>

