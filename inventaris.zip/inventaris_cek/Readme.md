DOKUMENTASI APLIKASI INVENTARIS

ERD :

![Screenshoot](img/ERD.jpeg)

#
DFD Context :

![Screenshoot](img/dfd-context.png)

#
DFD Level 0 :

![Screenshoot](img/dfd-lvl-0.png)

#
DFD Level 1 :

![Screenshoot](img/dfd-lvl-1.png)


Login menggunakan user admin :

Username : admin
Password : admin

Screenshoot :

![Screenshoot](img/ss0.png)

#
![Screenshoot](img/ss1.png)

#
![Screenshoot](img/ss2.png)

#
![Screenshoot](img/ss3.png)

#
![Screenshoot](img/ss4.png)

#test
