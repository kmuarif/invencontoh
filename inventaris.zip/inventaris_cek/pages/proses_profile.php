<?php 
include_once("../config/Class_Domain.php");
$db = new Class_Domain();
include_once("../config/config.php");

$aksi = $_GET["aksi"];

// ===========================================================================================
// BARANG BARU
// ===========================================================================================


if($aksi == "updateprofile")
{
    $kode_opd = $_POST["kode_opd"];
    $username = $_POST["username"];
    $NIP = $_POST["NIP"];
    $nama_user = $_POST["nama_user"];
    $telp_user = $_POST["telp_user"];
    $alamat_user = $_POST["alamat_user"];
    $alamat_user1 = stripslashes($alamat_user);
    // $query = $db->update_barang($nama_barang,$spesifikasi,$lokasi,$kategori,$kondisi,$jenis,$sumber_dana,$kode_barang);

    $query = mysqli_query($conn,"update tbl_useropd set
    nip_user= '$NIP', nama_user='$nama_user', telp_user='$telp_user', alamat_user='$alamat_user1' where username='$username'
    "); 


   //  $query = mysqli_query($conn,"update tbl_barang a inner join tbl_stok e on a.kode_barang=e.kode_barang set 
        
   //     a.nama_barang='".$nama_barang."',
   //    e.nama_barang='".$nama_barang."',
   //     a.spesifikasi='".$spesifikasi."',
   //     a.lokasi_barang='".$lokasi."',
   //     a.kategori='".$kategori."',
   //     a.kondisi='".$kondisi."',
   //     a.jenis_brg='".$jenis."',
   //     a.sumber_dana='".$sumber_dana."' where a.kode_barang='".$kode_barang."' ");

    // mengambil data barang keluar/masuk
   // $UPD = mysqli_query($conn,"select * from tbl_keluarbarang a inner join tbl_masukbarang b inner join tbl_pinjam c on a.kode_barang=b.kode_barang and b.kode_barang=c.kode_barang where a.kode_barang='".$kode_barang."' and  b.kode_barang='".$kode_barang."' and  c.kode_barang='".$kode_barang."' ");

   // $cek = mysqli_fetch_array($UPD);
    
    if ($query) {
        //if ($cek > 0) {
        //    $queryupdate  = mysqli_query($conn,"update tbl_domain set
        //    status_aktif= '$keaktifan', ket='$keterangan1' where kode_domain_opd='$kode_domain_edit' "); 
        //    if ($queryupdate) {
        //        echo "<script>alert('Data berhasil diubah'); window.location.href='../index.php?page=datadomain';</script>";
        //    }
        // }
                echo "<script>alert('Data Profile Berhasil Biubah'); window.location.href='../index.php?page=datadomain';</script>";

    }
    else
    {
        echo "Gagal";
    }


}