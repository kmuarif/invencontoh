<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Data Profile</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Update Data Diri
            </div>
            <div class="panel-body">
                <?php 
                    $nama_user = $_SESSION['nama_user'];
                    $username = $_SESSION['username'];
                    $kode_opd = $_SESSION['kode_opd'];
                    $sql = "select * from tbl_useropd where username='".$username."'";

                   $data = mysqli_query($conn,$sql);

                   $row = mysqli_fetch_array($data);
                 ?>

                <div class="row">
                    <div class="col-lg-6">
                    <form action="pages/proses_profile.php?aksi=updateprofile" method="post" enctype="multipart/form-data">
                                               
                            <div class="form-group">
                               <!-- <label>Kode OPD</label> -->
                                <input type="Hidden" name="kode_opd" value="<?=$row['kode_opd']?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" value="<?=$row['username']?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>NIP/PIN</label>
                                <input type="text" placeholder="Masukan NIP / PIN" name="NIP" class="form-control" required value="<?=$row['nip_user']?>" >
                            </div>
                            <div class="form-group">
                                <label>Nama Anda</label>
                                <input type="text" placeholder="Nama Sesuai Ktp" name="nama_user" class="form-control"  class="form-control" value="<?=$row['nama_user']?>" >
                            </div>
                           
                            
                    </div>
                    <!-- /.col-lg-6 (nested) -->
                    <div class="col-lg-6">
                        <div class="form-group"> 
                           <!-- <label>Keterangan Tambahan</label>
                           <textarea placeholder="Keterangan" name="keterangan" class="form-control" required ><?//=$row['ket']?></textarea> -->
                            <p> </p>
                        </div>
                        <div class="form-group">
                                <label>Nomor HP/WA</label>
                                <input type="text" placeholder="Isikan No WA/HP aktif" name="telp_user" class="form-control"  class="form-control" value="<?=$row['telp_user']?>" >
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                           <textarea placeholder="Alamat Tinggal sekarang" name="alamat_user" class="form-control" required ><?=$row['alamat_user']?></textarea>
                        </div>





                       <!-- <div class="form-group" >
                                <label>Status Keaktifan Domain</label>
                                <select name="keaktifan" class="form-control" required>
                                    <option value="1">Ya</option>
                                    <option value="0">Tidak</option>
                                </select>
                            </div>
                        
                        
                         <div class="form-group">
                            <label>Keterangan</label>
                            <textarea name="keterangan" class="form-control" required placeholder="keterangan"></textarea>
                        </div> -->
                    </div>

                     <div class="col-lg-12">
                            <button type="submit" name="submit" value="Simpan" class="btn btn-default" style="background-color: #333; color: #fff;">Submit</button>
                            <a href='?page=datadomain' class="btn btn-default" >Batal</a>
                        </div>
                    </form>
                        <?php  ?>
                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->