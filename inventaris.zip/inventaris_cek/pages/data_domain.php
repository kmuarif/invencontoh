<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Data Domain </h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Data Domain Opd
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
            <?php
            if (($_SESSION["akses_level"])=='1'){
              ?>
                
            
                <table width="100%" class="table table-striped table-bordered table-hover" cellpadding="0" cellspacing="0" id="dataTables-example">
                    <thead>
        <?php 
        
            if (is_array($db->tampil_data()) && count($db->tampil_data()) > 0) {

         ?>
                        <tr>
                            <th>No</th>
                            <th>Kode OPD</th>
                            <th>Nama Dinas PJ</th>
                            <th>Nama Domain</th>
                            <th>Status Aktif</th>
                            <th>Status Terkunci</th> 
                            <th>Tanggal Update Data</th>
                            <th>Akun Pengupdate</th> 
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php 
        $no = 1;

        foreach ($db->tampil_data() as $row) {

     ?>
                    <tr>
                        <td><?=$no++?></td>
                        <td><?=$row['kode_domain_opd']?></td>
                        <td><?=$row['nama_opd_pj']?></td>
                        <td><?=$row['nama_domain']?></td>
                        <!--<td><?//=$row['status_aktif']?></td> -->
                        <td style='display:none'><?=$row['status_aktif'];
                            $status=$row['status_aktif'];
                        
                        if($status=='1')
                        {
                            echo " <td style='display:block'>$status. YA </td>";
                        } else{
                            echo "<td style='display:block'>$status. TIDAK </td>";
                        }
                        
                        
                        ?>
                    
                    
                        </td>
                        
                        <td><?=$row['lock']?></td> 
                        <td><?=$row['tgl_update_data']?></td>
                        <td><?=$row['akun_pengupdate']?></td>
                        <td><?=$row['ket']?></td>
                        <td><a href="?id=<?=$row['id_domain']?>&page=update">Edit</a> - <a href="?hapus&id=<?=$row['id_domain']?>" onclick="return confirm('Yakin mau dihapus?');">Hapus</a></td>
                        
                    </tr>
    <?php } 
}?>
                    </tbody>
                </table>
            
            <?php 
            }else{

                $username = $_SESSION["username"];
                $sql = "select * from tbl_useropd WHERE username = '$username' ";

                $data = mysqli_query($conn,$sql);

                $row = mysqli_fetch_array($data);     
                    if ($row['locking_data_domain']=='0')
                    {
                    ?>
                    
            
                <table width="100%" class="table table-striped table-bordered table-hover" cellpadding="0" cellspacing="0" id="dataTables-example">
                    <thead>
        <?php 
        
            if (is_array($db->tampil_data()) && count($db->tampil_data()) > 0) {

         ?>
                        <tr>
                            <th>No</th>
                            <th>Kode OPD</th>
                            <th>Nama Dinas PJ</th>
                            <th>Nama Domain</th>
                            <th>Status Aktif</th>
                        <!--<th>Status Terkunci</th> -->
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php 
        $no = 1;

        foreach ($db->tampil_data() as $row) {

     ?>
                    <tr>
                        <td><?=$no++?></td>
                        <td><?=$row['kode_domain_opd']?></td>
                        <td><?=$row['nama_opd_pj']?></td>
                        <td><?=$row['nama_domain']?></td>
                        <td style='display:none'><?=$row['status_aktif'];
                            $status=$row['status_aktif'];
                        
                        if($status=='1')
                        {
                            echo " <td style='display:block'> YA </td>";
                        } else{
                            echo "<td style='display:block'> TIDAK </td>";
                        }
                        
                        
                        ?>
                    
                    
                        </td>
                       <!-- <td><?=$row['lock']?></td> -->
                        <td><?=$row['ket']?></td>
                        <td><a href="?id=<?=$row['id_domain']?>&page=update">Edit</a>
                        
                    </tr>
    <?php } 
}?>
                    </tbody>
                </table>

                <!-- /.table-responsive -->
                <a href="?kunci&id=<?=$row['kode_domain_opd']?>" onclick="return confirm('Yakin mau dikunci?');" class="btn btn-primary btn-lg btn-block" name="kunci_data" role="button" aria-pressed="true">KUNCI DATA</a>

                    <?php }else{
                        ?>

            
<table width="100%" class="table table-striped table-bordered table-hover" cellpadding="0" cellspacing="0" id="dataTables-example">
                    <thead>
        <?php 
        
            if (is_array($db->tampil_data()) && count($db->tampil_data()) > 0) {

         ?>
                        <tr>
                            <th>No</th>
                            <th>Kode OPD</th>
                            <th>Nama Dinas PJ</th>
                            <th>Nama Domain</th>
                            <th>Status Aktif</th>
                        <!--<th>Status Terkunci</th> -->
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php 
        $no = 1;

        foreach ($db->tampil_data() as $row) {

     ?>
                    <tr>
                        <td><?=$no++?></td>
                        <td><?=$row['kode_domain_opd']?></td>
                        <td><?=$row['nama_opd_pj']?></td>
                        <td><?=$row['nama_domain']?></td>
                        <td style='display:none'><?=$row['status_aktif'];
                            $status=$row['status_aktif'];
                        
                        if($status=='1')
                        {
                            echo " <td style='display:block'> YA </td>";
                        } else{
                            echo "<td style='display:block'> TIDAK </td>";
                        }
                        
                        
                        ?>
                    
                    
                        </td>
                        <!-- <td><?=$row['lock']?></td> -->
                        <td><?=$row['ket']?></td>
                        <td><a href="#">Terkunci</a>                       
                    </tr>
    <?php } 
}?>
                    </tbody>
                </table>

                
                    <?php } ?>
                <?php } ?>
                
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->