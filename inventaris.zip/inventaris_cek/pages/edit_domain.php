<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Data Domain</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Update Domain Terpilih
            </div>
            <div class="panel-body">
                <?php 
                   // foreach ($db->edit_domain($_GET['id']) as $row) {
                   // include("../config.php");
                    $id         = $_GET['id'];
                    //            $db->edit_domain($_GET['id']
                   // $edit_domain  = mysqli_query($con, "select * from tbl_domain where id_domain='.$id.'");
                   $sql = "select * from tbl_domain where id_domain='".$id."'";

                   $data = mysqli_query($conn,$sql);

                   $row = mysqli_fetch_array($data);
                 ?>

                <div class="row">
                    <div class="col-lg-6">
                    <form action="pages/proses_domain.php?aksi=updatedomain" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                              <!--  <label>Kode domain</label> -->
                                <input type="hidden" name="id_domain" value="<?=$row['id_domain']?>" class="form-control" readonly>
                            </div>
                    
                            <div class="form-group">
                                <label>Kode domain</label>
                                <input type="text" name="kode_domain" value="<?=$row['kode_domain_opd']?>" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Nama Dinas PJ</label>
                                <input type="text" placeholder="Masukan Nama Dinas PJ" name="nama_dinas_pj" class="form-control" required value="<?=$row['nama_opd_pj']?>" readonly >
                            </div>
                            <div class="form-group">
                                <label>Nama Domain</label>
                                <input type="text" placeholder="Nama Domain" name="nama_domain" class="form-control"  class="form-control" value="<?=$row['nama_domain']?>" readonly>
                            </div>
                           
                            
                    </div>
                    <!-- /.col-lg-6 (nested) -->
                    <div class="col-lg-6">
                        <div class="form-group" >
                                <label>Status Keaktifan Domain</label>
                                <select name="keaktifan" class="form-control" required>
                                    <option value="1">Ya</option>
                                    <option value="0">Tidak</option>
                                </select>
                            </div>
                        <div class="form-group">
                            <label>Keterangan Tambahan</label>
                           <textarea placeholder="Keterangan" name="keterangan" class="form-control" required ><?=$row['ket']?></textarea>
                        </div>
                        <?php
                        $date = date("h:i:s A d F Y"); 
                        $tz = 'Asia/Jakarta';
                        $dt = new DateTime("now", new DateTimeZone($tz));
                        $timestamp = $dt->format('G:i:s');
                        $timestamp1 = $dt->format('d F Y');
                        $timestamp2=$timestamp." WIB ".$timestamp1;
                        ?>
                        <div class="form-group">
                           <!-- <label>Tanggal Update</label> -->
                          <!--  <input type="" name="tgl_updated" class="form-control" value="<?//=$timestamp2." - ".$_SESSION['username']; ?>" required placeholder="tanggal update data"></input> --> 
                            <input type="hidden" name="tgl_updated" class="form-control" value="<?=$timestamp2?>" required placeholder="tanggal update data"></input>
                        </div>
                        <div class="form-group">
                           <!-- <label>Akun Pengupdate</label> -->
                           <input type="hidden" name="akun_pengupdate" class="form-control" value="<?=$_SESSION['username']; ?>" required placeholder=" tukang update data"></input>
                        </div>
                    </div>

                     <div class="col-lg-12">
                            <button type="submit" name="submit" value="Simpan" class="btn btn-default" style="background-color: #333; color: #fff;">Submit</button>
                            <a href='?page=datadomain' class="btn btn-default" >Batal</a>
                        </div>
                    </form>
                        <?php  ?>
                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->