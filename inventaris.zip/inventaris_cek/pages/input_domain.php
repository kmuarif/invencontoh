<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Domain</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Input Domain Baru untuk di Verifikasi 
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                    <form action="pages/proses_domain.php?aksi=tambah" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Kode Opd</label>
                                <select name="kode_opd" id="kode_opd" class="form-control" required>
                                        <option disabled selected> Pilih </option>
                                <?php 
                                //include ('../config/config.php');
                               // $sql = "select * from tbl_opd ";

                               // $data = mysqli_query($conn,$sql);
                                                                 

                                     foreach ($db->tampil_data_opd() as $row) {
                                        ?>
                                        <option value="<?=$row['kode_opd']?>">(<?=$row['kode_opd'].")-".$row['nama_opd']?></option>

                                   <?php  }   
                                     ?>
                                     </select>
                                 
                            </div>
                            <div class="form-group">
                                <label>Nama Opd</label>
                                <input type="text" placeholder="Nama Opd" name="nama_opd_pj" class="form-control" value="Masih proses" readonly>
                            </div>
                            <div class="form-group">
                                <label>Nama Domain</label>
                                <input type="text" placeholder="Nama Domain" name="nama_domain" class="form-control"  class="form-control">
                            </div>
                           <div class="form-group">
                                <label>Status Aktif</label>
                                <input type="text" placeholder="Status" name="status_aktif" class="form-control" value='1' required >
                            </div>
                            
                    </div>
                    <!-- /.col-lg-6 (nested) -->
                    <div class="col-lg-6">
                       <!-- <div class="form-group">
                                <label>Kondisi</label>
                                <select name="kondisi" class="form-control" required>
                                    <option value="">Pilih Kondisi</option>
                                    <option value="Baru">Baru</option>
                                    <option value="Bekas">Bekas</option>
                                </select>
                        </div> -->
                        <div class="form-group">
                            <label>Status Terkunci</label>
                            <input  type="text" placeholder="Status Kuncian" name="lock" class="form-control" value='0' required>
                        </div>
                        <div class="form-group">
                            <label>Keterangan</label>
                            <textarea name="ket" class="form-control" required placeholder="keterangan"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" value="Simpan" class="btn btn-default" style="background-color: #333; color: #fff;">Submit</button>
                            <a href='?page=databarang' class="btn btn-default" >Batal</a>
                        </div>
                        </form>
                    </div>
                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->