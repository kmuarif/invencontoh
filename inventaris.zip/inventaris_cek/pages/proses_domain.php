<?php 
include_once("../config/Class_Domain.php");
$db = new Class_Domain();
include_once("../config/config.php");

$aksi = $_GET["aksi"];
//$akun_pengupdate=$_SESSION['username'];

// ===========================================================================================
// BARANG BARU
// ===========================================================================================

if ($aksi == "tambah") {

    //====================================================
    // nilai paten awal input
    //====================================================
    $tanggalupdate='Belum diupdate mase';
    $akun_awal_isi='';
    //====================================================
    $id_domain='harusauto';
    $kode_opd = $_POST["kode_opd"];
    $nama_opd_pj = $_POST["nama_opd_pj"];
    $nama_domain = $_POST["nama_domain"];
    $status_aktif = $_POST["status_aktif"];
    $lock = $_POST["lock"];

    $ket = $_POST["ket"];
    
    $db->input_domainbaru($id_domain,$kode_opd,$nama_opd_pj,$nama_domain,$status_aktif,$lock,$ket,$tanggalupdate,$akun_awal_isi);

    echo "<script>alert('Data domain tersimpan'); window.location.href='../index.php?page=datadomain';</script>";

}

// ===========================================================================================
// BARANG MASUK
// ===========================================================================================
else if($aksi == "tambahbarangmasuk"){

    $nama_supplier = $_POST["nama_supplier"];
    $id_barangmasuk = $_POST["id_masukbarang"];
    $nama_barang = $_POST["nama_barang"];
    $tgl = $_POST["tgl_masuk"];
    $jumlah = $_POST["jumlah_masuk"];

    $kdsup = mysqli_query($conn,"select kode_supplier from tbl_supplier where nama_supplier='".$nama_supplier."'");
    $skode = mysqli_fetch_array($kdsup);
    $kode_supplier = $skode["kode_supplier"];

    $kdbarang = mysqli_query($conn,"select kode_barang from tbl_barang where nama_barang='".$nama_barang."' ");
    $skodebrg = mysqli_fetch_array($kdbarang);
    $kode_barang = $skodebrg["kode_barang"];

    $stok = mysqli_query($conn,"select * from tbl_stok where kode_barang ='".$kode_barang."' ");
    $tmpstok = mysqli_fetch_array($stok);

    $jml_barang = $tmpstok["jml_barangmasuk"];
    $jml_barangkeluar = $tmpstok["jml_barangkeluar"];
    $total = $tmpstok["total_barang"];

    $jml_barangmasuk = $jumlah + $jml_barang;
    $totalbarang = $jumlah + $jml_barang;
    $totjumlah_barang = $totalbarang - $jml_barangkeluar;

    $db->input_barangmasuk($id_barangmasuk,$kode_barang,$nama_barang,$tgl,$jumlah,$kode_supplier,$jml_barangmasuk,$totalbarang,$totjumlah_barang);
    
    echo "<script>alert('Barang masuk berhasil ditambahkan'); window.location.href='../index.php?page=inputbarangmasuk';</script>";

}

// ===========================================================================================
// PINJAM BARANG
// ===========================================================================================
else if($aksi == "tambahdatapinjam"){

    $no_pinjam = $_POST["no_pinjam"];
    $tgl_pinjam = $_POST["tgl_pinjam"];
    $nama_barang = $_POST["nama_barang"];
    $tgl_kembali = $_POST["tgl_kembali"];
    $jumlah_pinjam = $_POST["jumlah_pinjam"];
    $nama_peminjam = $_POST["nama_peminjam"];
    $keterangan = $_POST["keterangan"];


    $kodebrg =  mysqli_query($conn,"select kode_barang, jumlah_brg from tbl_barang where nama_barang='".$nama_barang."'");
    $kd = mysqli_fetch_array($kodebrg); 
    $kode_barang = $kd["kode_barang"]; 
    $jumlah_brg = $kd["jumlah_brg"];

    $totalbarang = $jumlah_brg - $jumlah_pinjam;

    $cekstok = mysqli_query($conn,"select jml_barangkeluar,total_barang from tbl_stok where kode_barang='".$kode_barang."'");
    $cek = mysqli_fetch_array($cekstok);
    $jumlah_barangkeluar = $cek["jml_barangkeluar"];
    // $tot_stok = $cek["total_barang"];
    // $total_stok = $tot_stok - $jumlah_pinjam;

    $totbarangkeluar = $jumlah_barangkeluar + $jumlah_pinjam;

    if ($jumlah_pinjam > $jumlah_brg) {

        echo "<script>alert('Jumlah barang yang dipinjam terlalu banyak! Jumlah barang tersedia hanya = $jumlah_brg, mohon kembali input ulang.'); window.location.href='../index.php?page=formpeminjaman';</script>";

    }
    else{
        
        $db->input_datapeminjaman($no_pinjam,$tgl_pinjam,$kode_barang,$nama_barang,$jumlah_pinjam,$nama_peminjam,$tgl_kembali,$keterangan,$totalbarang,$totbarangkeluar);
   
    echo "<script>alert('Data peminjaman tersimpan'); window.location.href='../index.php?page=peminjaman';</script>";
        
    }

}


// ===========================================================================================
// KEMBALI BARANG
// ===========================================================================================

else if($aksi == "kembalibarang"){

    $no_pinjam = $_POST["no_pinjam"];
    $status = $_POST["status"];

    $query = mysqli_query($conn,"select * from tbl_pinjam a inner join tbl_barang b on a.kode_barang=b.kode_barang where a.nomor_pinjam='$no_pinjam'");
    $data = mysqli_fetch_array($query);

    $jumlah_pinjam = $data["jumlah_pinjam"];
    $kode_barang = $data["kode_barang"];
    $keterangan = $data["keterangan"];
    $jumlah_brg = $data["jumlah_brg"];

    $query2 = mysqli_query($conn,"select * from tbl_stok where kode_barang='$kode_barang'");
    $data2 = mysqli_fetch_array($query2);
    $barangkeluar = $data2["jml_barangkeluar"];

    $jumlah_barang = $jumlah_brg + $jumlah_pinjam;
    $stok = $barangkeluar - $jumlah_pinjam;

    if ($keterangan == "Sudah dikembalikan") {
        echo "<script>alert('Barang ini sudah dikembalikan sebelumnya!'); window.location.href='../barang.php?page=peminjaman';</script>";

    }
    else{
        $db->update_datapeminjaman($jumlah_barang,$kode_barang,$status,$no_pinjam,$stok);
        echo "<script>alert('Data barang dikembalikan ke stok'); window.location.href='../index.php?page=peminjaman';</script>";

    }

}

else if($aksi == "updatedomain")
{
    $id_domain_edit = $_POST["id_domain"];
    $kode_domain_edit = $_POST["kode_domain"];
   // $nama_dinas_pj = $_POST["nama_dinas_pj"];
   // $nama_domain = $_POST["nama_domain"];
    $keaktifan = $_POST["keaktifan"];
    $keterangan = $_POST["keterangan"];
    $keterangan1 = stripslashes($keterangan);
    $tgl_updated = $_POST["tgl_updated"];
    $akun_pengupdate=$_POST["akun_pengupdate"];
    // $query = $db->update_barang($nama_barang,$spesifikasi,$lokasi,$kategori,$kondisi,$jenis,$sumber_dana,$kode_barang);

    $query = mysqli_query($conn,"update tbl_domain set
    status_aktif= '$keaktifan', ket='$keterangan1', tgl_update_data='$tgl_updated', akun_pengupdate='$akun_pengupdate' where id_domain='$id_domain_edit'
    "); 


   //  $query = mysqli_query($conn,"update tbl_barang a inner join tbl_stok e on a.kode_barang=e.kode_barang set 
        
   //     a.nama_barang='".$nama_barang."',
   //    e.nama_barang='".$nama_barang."',
   //     a.spesifikasi='".$spesifikasi."',
   //     a.lokasi_barang='".$lokasi."',
   //     a.kategori='".$kategori."',
   //     a.kondisi='".$kondisi."',
   //     a.jenis_brg='".$jenis."',
   //     a.sumber_dana='".$sumber_dana."' where a.kode_barang='".$kode_barang."' ");

    // mengambil data barang keluar/masuk
   // $UPD = mysqli_query($conn,"select * from tbl_keluarbarang a inner join tbl_masukbarang b inner join tbl_pinjam c on a.kode_barang=b.kode_barang and b.kode_barang=c.kode_barang where a.kode_barang='".$kode_barang."' and  b.kode_barang='".$kode_barang."' and  c.kode_barang='".$kode_barang."' ");

   // $cek = mysqli_fetch_array($UPD);
    
    if ($query) {
        //if ($cek > 0) {
        //    $queryupdate  = mysqli_query($conn,"update tbl_domain set
        //    status_aktif= '$keaktifan', ket='$keterangan1' where kode_domain_opd='$kode_domain_edit' "); 
        //    if ($queryupdate) {
        //        echo "<script>alert('Data berhasil diubah'); window.location.href='../index.php?page=datadomain';</script>";
        //    }
        // }
                echo "<script>alert('Data berhasil diubah'); window.location.href='../index.php?page=datadomain';</script>";

    }
    else
    {
        echo "Gagal";
    }


}