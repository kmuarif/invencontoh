<?php 



include_once("config/Class_Domain.php");
$db = new Class_Domain();


include_once("config/Class_User.php");
$cu = new Class_User();


include_once("config/Class_Dataall.php");
$st = new Class_Dataall();

include_once("config/config.php");



if (isset($_GET['hapus'])) {

    $db->hapus($_GET['id']);
    echo "<script>alert('Domain berhasil dihapus'); window.location.href='index.php?page=datadomain';</script>";
}
if (isset($_GET['kunci'])) {

    $db->kunci($_GET['id']);
    //echo"($db)";
    echo "<script>alert('Semua Domain berhasil dikunci'); window.location.href='index.php?page=datadomain';</script>";
}


 ?>
<!DOCTYPE html>
<html lang="en">
<?php 

 
include_once("config/Class_Domain.php");
$db = new Class_Domain();

 ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Inventarisku</title>

    <?php 
    include_once("includes/header.php"); ?>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
            <?php include_once("includes/navbar.php"); ?>
            <!-- /.navbar-top-links -->
            <?php include_once("includes/sidebar.php"); ?>
            
            <!-- /.navbar-static-side -->
        <div id="page-wrapper">

<?php 

        if (isset($_GET['page']) && $_GET['page'] == "datadomain") {

            include_once("pages/data_domain.php");
        }
        else if (isset($_GET['page']) && $_GET['page'] == "inputdomain") {

            include_once("pages/input_domain.php");
        }
        else if (isset($_GET['page']) && $_GET['page'] == "update") {

            include_once("pages/edit_domain.php");
        }
        else if (isset($_GET['page']) && $_GET['page'] == "dataall") {

            include_once("dataall/data_all.php");
        }
        else if (isset($_GET['page']) && $_GET['page'] == "profile") {

            include_once("pages/profile.php");
        }
        else if (isset($_GET['page']) && $_GET['page'] == "pengaturan") {

            include_once("pages/pengaturan.php");
        }  
        else{
            include_once("pages/dashboard.php");
        }

 ?>
            
        </div>
        <!-- /#pag-wrapper -->

    </div>
    <!-- /#wrapper -->

   <?php include_once("includes/footer.php"); ?>

<!-- <script>
$(document).ready(function() {
$('#dataTables-example').DataTable({
responsive: true
});
});
</script>
 -->
</body>

</html>
