<?php 

/**
* 
*/
class Class_Domain
{

    // =====================================================================================
    // AMBIL DATA
    // ======================================================================================
  /*  function hitung_data()
    {
        include("config.php");

        $sql = "select * from tbl_domain a inner join tbl_stok c on a.kode_Domain=c.kode_Domain";

        $data = mysqli_query($conn,$sql);

        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            // echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }
*/
     function tampil_data()
    {
        include("config.php");
        $kode_opd=$_SESSION['kode_opd'];
        if (($_SESSION["akses_level"])=='1'){
                $sql = "select * from tbl_domain";

                $data = mysqli_query($conn,$sql);

                $data1 = mysqli_num_rows($data);
                if ($data1 == 0) {

                    echo "<div class='alert alert-danger'>Tidak ada data</div>";
                }
                else{
                    
                    while ($d=mysqli_fetch_assoc($data)) {

                        $hasil[] = $d;
                    }
                    return $hasil;
                }
        }else{
            $kode_opd=$_SESSION['kode_opd'];
            $sql = "select * from tbl_domain where kode_domain_opd='$kode_opd' ";

            $data = mysqli_query($conn,$sql);

            $data1 = mysqli_num_rows($data);
            if ($data1 == 0) {

                echo "<div class='alert alert-danger'>Tidak ada data</div>";
            }
            else{
                
                while ($d=mysqli_fetch_assoc($data)) {

                    $hasil[] = $d;
                }
                return $hasil;
            }







        }
    }


    function tampil_data_print()
    {
        include("config.php");
        $kode_opd=$_SESSION['kode_opd'];
        if (($_SESSION["akses_level"])=='1'){
                $sql = "select * from tbl_domain";

                $data = mysqli_query($conn,$sql);

                $data1 = mysqli_num_rows($data);
                if ($data1 == 0) {

                    echo "<div class='alert alert-danger'>Tidak ada data</div>";
                }
                else{
                    
                    while ($d=mysqli_fetch_assoc($data)) {

                        $hasil[] = $d;
                    }
                    return $hasil;
                }
        }else{
            $kode_opd=$_SESSION['kode_opd'];
            $sql = "select * from tbl_domain where kode_domain_opd='$kode_opd' ";

            $data = mysqli_query($conn,$sql);

            $data1 = mysqli_num_rows($data);
            if ($data1 == 0) {

                echo "<div class='alert alert-danger'>Tidak ada data</div>";
            }
            else{
                
                while ($d=mysqli_fetch_assoc($data)) {

                    $hasil[] = $d;
                }
                return $hasil;
            }







        }
    }

    function tampil_data_opd()
    {
        include("config.php");
        $sql = "select * from tbl_opd";

                $data = mysqli_query($conn,$sql);

                $data1 = mysqli_num_rows($data);
                if ($data1 == 0) {

                    echo "<div class='alert alert-danger'>Tidak ada data</div>";
                }
                else{
                    
                    while ($d=mysqli_fetch_assoc($data)) {

                        $hasil[] = $d;
                    }
                    return $hasil;
                }

        
    }

















/*
    function tampil_Domainmasuk()
    {
        include("config.php");

        $sql = "select * from tbl_domain a inner join tbl_masukDomain b inner join tbl_stok c on a.kode_Domain=b.kode_Domain and a.kode_Domain=c.kode_Domain inner join tbl_supplier d on b.kode_supplier=d.kode_supplier ORDER BY b.tgl_masuk DESC";
        
        // echo $sql;
        $data = mysqli_query($conn,$sql);
        
        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }

    function tampil_peminjaman()
    {
         include("config.php");

        $sql = "select * from tbl_pinjam order by tgl_pinjam DESC";

        $data = mysqli_query($conn,$sql);

        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }

    function tampil_Domainkeluar()
    {
         include("config.php");

        $sql = "select * from tbl_keluarDomain";

        $data = mysqli_query($conn,$sql);

        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }

*/
    // mengambil nama dan id_supplier
    function supplier()
    {
        include("config.php");

        $sql = "select * from tbl_supplier order by kode_supplier";

        $data = mysqli_query($conn,$sql);

        while ($d=mysqli_fetch_assoc($data)) {

            $hasil[] = $d;
        }
        return $hasil;
    }

    // mengambil nama dan kode_Domain
    function Domain()
    {
        include("config.php");
        $kode_opd=$_SESSION['kode_opd'];
        if (($_SESSION["akses_level"])=='1'){
                $sql = "select * from tbl_domain order by kode_domain_opd";

                $data = mysqli_query($conn,$sql);

                 while ($d=mysqli_fetch_assoc($data)) {

                    $hasil[] = $d;
                }
            return $hasil;
        }else{
            $kode_opd=$_SESSION['kode_opd'];
           // $sql = "select * from tbl_domain where kode_domain_opd='".$kode_opd."' ";
            $sql = "select * from tbl_domain where kode_domain_opd='".$kode_opd."' ";

            $data = mysqli_query($conn,$sql);

             while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
        return $hasil;




        }


    }

    // ======================================================================================
    // INPUT DATA
    // ======================================================================================

    function input_domainbaru($id_domain,$kode_opd,$nama_opd_pj,$nama_domain,$status_aktif,$lock,$ket,$tanggalupdate,$akun_awal_isi)
    {
        // $kode_Domain = addslashes($kode_Domain);
        $id_domain = addslashes($id_domain);
        $kode_opd = addslashes($kode_opd);
        $nama_opd_pj = addslashes($nama_opd_pj);
        $nama_domain = addslashes($nama_domain);
        $status_aktif = $status_aktif;
        $lock = $lock;
        $ket = addslashes($ket);
        $tanggalupdate = addslashes($tanggalupdate);
        $akun_awal_isi = addslashes($akun_awal_isi);

        include("config.php");

        $sql1 = "insert into tbl_domain values('$id_domain','$kode_opd','$nama_opd_pj','$nama_domain','$status_aktif','$lock','$ket','$tanggalupdate','$akun_awal_isi')";
        // echo $sql1;
        $data1 = mysqli_query($conn,$sql1);


        //$sql2 = "insert into tbl_stok values('$kode_Domain','$nama_Domain','$stok','$jmlkeluar','$stok-$jmlkeluar','$keterangan')";
        // echo $sql2;
       // $data2 = mysqli_query($conn,$sql2);
    }

    function input_Domainmasuk($id_Domainmasuk,$kode_Domain,$nama_Domain,$tgl,$jumlah,$kode_supplier,$jml_Domainmasuk,$totalDomain,$totjml_Domain)
    {
        // $id_Domainmasuk = addslashes($id_Domainmasuk);
        $kode_Domain = addslashes($kode_Domain);
        $nama_Domain = addslashes($nama_Domain);
        $tgl = addslashes($tgl);
        $jumlah = addslashes($jumlah);
        $kode_supplier = addslashes($kode_supplier);
        $jml_Domainmasuk = addslashes($jml_Domainmasuk);
        $totalDomain = addslashes($totalDomain);
        $totjml_Domain = addslashes($totjml_Domain);

        include("config.php");

        // Menyimpan Domain masuk
        $sql1 = "insert into tbl_masukDomain values('".$id_Domainmasuk."','".$kode_Domain."','".$nama_Domain."','".$tgl."','".$jumlah."','".$kode_supplier."')";
        // echo $sql1;
        $data1 = mysqli_query($conn,$sql1);

        // update tbl_stok
        $sql2 = "update tbl_stok set jml_Domainmasuk='".$jml_Domainmasuk."', total_Domain='".$totalDomain."' where kode_Domain='".$kode_Domain."' ";
        // echo $sql2;
        $data2 = mysqli_query($conn,$sql2);

        // update tbl_domain
        $sql3 = "update tbl_domain set jumlah_brg='".$totjml_Domain."' where kode_Domain='".$kode_Domain."'";
        // echo $sql3;
        $data3 = mysqli_query($conn,$sql3);

    }

    function input_datapeminjaman($no_pinjam,$tgl_pinjam,$kode_Domain,$nama_Domain,$jumlah_pinjam,$nama_peminjam,$tgl_kembali,$keterangan,$totalDomain,$jmlDomainkeluar)
    {
        include("config.php");

        $sql = "insert into tbl_keluarDomain values('".$no_pinjam."','".$kode_Domain."','".$nama_Domain."','".$tgl_pinjam."','".$nama_peminjam."','".$jumlah_pinjam."')";
        // echo $sql;
        $data = mysqli_query($conn,$sql);

        $sql1 = "insert into tbl_pinjam values('".$no_pinjam."','".$tgl_pinjam."','".$kode_Domain."','".$nama_Domain."','".$jumlah_pinjam."','".$nama_peminjam."','".$tgl_kembali."','".$keterangan."')";
        // echo $sql1;
        $data1 = mysqli_query($conn,$sql1);

        $sql2 = "update tbl_domain set jumlah_brg='".$totalDomain."' where kode_Domain='".$kode_Domain."'";
        // echo $sql2;

        $data2 = mysqli_query($conn,$sql2);

        $sql3 = "update tbl_stok set jml_Domainkeluar='".$jmlDomainkeluar."' where kode_Domain='".$kode_Domain."'";
        // echo $sql3;

        $data3 = mysqli_query($conn,$sql3);





    }

    // ======================================================================================
    // UPDATE DATA
    // ======================================================================================
    
    function update_datapeminjaman($jumlah_brg,$kode_Domain,$keterangan,$no_pinjam,$stok)
    {
        include("config.php");
        $sql1 = "update tbl_domain set jumlah_brg='".$jumlah_brg."' where kode_Domain='".$kode_Domain."'";
        // echo $sql1;

        $data1 = mysqli_query($conn,$sql1);

        $sql2 = "update tbl_pinjam set keterangan='".$keterangan."' where nomor_pinjam='".$no_pinjam."'";
        // echo $sql2;

        $data2 = mysqli_query($conn,$sql2);

        $sql3 = "update tbl_stok set jml_Domainkeluar='".$stok."' where kode_Domain='".$kode_Domain."'";
        // echo $sql3;

        $data3 = mysqli_query($conn,$sql3);
    }

    function edit_Domain($kode_Domain)
    {
        include("config.php");

        $sql = "select * from tbl_domain where kode_domain_opd='".$kode_Domain."'";

        $data = mysqli_query($conn,$sql);

        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }

    function update_Domain($nama_Domain,$spesifikasi,$lokasi_Domain,$kategori,$kondisi,$jenis_Domain,$sumber_dana,$kode_Domain)
    {
        include("config.php");

        $sql = "update tbl_domain a inner join tbl_stok e on a.kode_Domain=e.kode_Domain set 
        
        a.nama_Domain='".$nama_Domain."',
        e.nama_Domain='".$nama_Domain."',
        a.spesifikasi='".$spesifikasi."',
        a.lokasi_Domain='".$lokasi_Domain."',
        a.kategori='".$kategori."',
        a.kondisi='".$kondisi."',
        a.jenis_brg='".$jenis_Domain."',
        a.sumber_dana='".$sumber_dana."' where a.kode_Domain='".$kode_Domain."' ";

        // echo $sql;
        $data = mysqli_query($conn,$sql);

    }
    // ======================================================================================
    // HAPUS DATA
    // ======================================================================================


    function hapus($id)
    {
        include ("config.php");

        $sql1 = "delete from tbl_domain where kode_Domain='".$id."' ";
        $data1 = mysqli_query($conn,$sql1);
        /*
        $sql2 = "delete from tbl_stok where kode_Domain= '".$id."' ";
        $data2 = mysqli_query($conn,$sql2);

        $sql3 = "delete from tbl_pinjam where kode_Domain= '".$id."' ";
        $data3 = mysqli_query($conn,$sql3);

        $sql4 = "delete from tbl_masukDomain where kode_Domain= '".$id."' ";
        $data4 = mysqli_query($conn,$sql4);

        $sql5 = "delete from tbl_keluarDomain where kode_Domain= '".$id."' ";
        $data5 = mysqli_query($conn,$sql5);
        */
    }

    // ======================================================================================
    // KUNCI DATA
    // ======================================================================================


    function kunci($id)
    {
        include ("config.php");
        
        $sql2 = "update tbl_useropd set locking_data_domain='1' where kode_opd='".$id."'";
        $data2 = mysqli_query($conn,$sql2);

       //$sql1 = "update tbl_domain set lock='1' where kode_domain_opd='$id'";
       //$data1 = mysqli_query($conn,$sql1);
       // echo "$id";

        
        /*
        $sql3 = "delete from tbl_pinjam where kode_Domain= '".$id."' ";
        $data3 = mysqli_query($conn,$sql3);

        $sql4 = "delete from tbl_masukDomain where kode_Domain= '".$id."' ";
        $data4 = mysqli_query($conn,$sql4);

        $sql5 = "delete from tbl_keluarDo   main where kode_Domain= '".$id."' ";
        $data5 = mysqli_query($conn,$sql5);
        */
    }



}
 ?>