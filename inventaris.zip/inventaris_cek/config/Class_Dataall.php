<?php 
/**
* 
*/
class Class_Dataall
{
    
   function tampil_data_print()
    {
        include("config.php");
        $kode_opd=$_SESSION['kode_opd'];
        $sql = "select * from tbl_domain where kode_domain_opd='$kode_opd'
 ORDER BY id_domain ASC";

        $data = mysqli_query($conn,$sql);

        $data1 = mysqli_num_rows($data);
        if ($data1 == 0) {

            echo "<div class='alert alert-danger'>Tidak ada data</div>";
        }
        else{
            
            while ($d=mysqli_fetch_assoc($data)) {

                $hasil[] = $d;
            }
            return $hasil;
        }
    }
}
 ?>