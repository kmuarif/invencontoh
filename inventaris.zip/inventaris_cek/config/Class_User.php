<?php 
/**
* 
*/
class Class_User
{
    
    function login($username,$password)
    {
        $username = addslashes($username);
        $password = base64_encode(md5($password , true));
        $password = addslashes($password);

        include("config.php");

        $sql = "select * from tbl_useropd where username='".$username."' and password='".$password."'";
        // echo $sql;
        $data = mysqli_query($conn,$sql);

        $user_data = mysqli_fetch_object($data);

        $no_rows = mysqli_num_rows($data);
        if ($no_rows == 1) {

            session_start();
            $_SESSION['id_useropd'] = $user_data->id_useropd;
            $_SESSION['kode_opd'] = $user_data->kode_opd;
            $_SESSION['username'] = $user_data->username;
            $_SESSION['nip_user'] = $user_data->nip_user;
            $_SESSION['nama_user'] = $user_data->nama_user;
            $_SESSION['akses_level'] = $user_data->akses_level;
            $_SESSION['locking_data_domain'] = $user_data->locking_data_domain;
            header("location:index.php");
            return true;
        }
        else{
            return false;
        }
    }

    function cek_password($id_useropd,$password)
    {
        $password = base64_encode(md5($password, true));

        include("config.php");

       // $sql = "select * from tbl_useropd where id_useropd='".$id_useropd."' and password='".$password."'";
       $sql = "select * from tbl_useropd where id_useropd='$id_useropd' and password='$password'";
       //print_r($sql);
        $data = mysqli_query($conn,$sql);
        while ($d = mysqli_fetch_assoc($data)) {

            $hasil[] = $d;
        }
        error_reporting(0);
       // print_r($hasil);
       return $hasil;
    }

    function update_password($password,$id)
    {
        $password = base64_encode(md5($password, true));
        $password = addslashes($password);

        include("config.php");

        //$sql = "update tbl_useropd set password='".$password."' where id_user='".$id."'";
        $sql = "update tbl_useropd set password='$password' where id_useropd='$id'";
        // echo $sql;
        $data = mysqli_query($conn,$sql);
    }

    // function cek_user($username,$password)
    // {
    //     $username = addslashes($username);
    //     $password = base64_encode(md5($password, true));
    //     $password = addslashes($password);

    //     include('config.php');

    //     $sql = "select * from user username='".$username."' and password='".$password."'";
    //     // echo $sql;

    //     $data = mysqli_query($conn,$sql);
    // }

    // function tambah_user($nama,$username,$password,$level)
    // {
    //     $nama = addslashes($nama);
    //     $username = addslashes($username);
    //     $password = base64_encode(md5($password, true));
    //     $password = addslashes($password);
    //     $level = addslashes($level);

    //     include('config.php');

    //     $sql = "insert into user (nama,username,password,level) values('".$nama."','".$username."','".$password."','".$level."')";

    //     $data = mysqli_query($conn,$sql);

    // }

    // function edit($id)
    // {
    //     include('config.php');

    //     $sql = "select * from user";

    //     $data = mysqli_query($conn,$sql);

    //     while ($d = mysqli_fetch_assoc($data)) {

    //         $hasil[] = $d;
    //     }

    //     return $hasil;
    // }

    // function update($nama,$username,$password,$level)
    // {
    //     $nama = addslashes($nama);
    //     $username = addslashes($username);
    //     $password = base64_encode(md5($password, true));
    //     $password = addslashes($password);
    //     $level = addslashes($level);

        
    // }
}

 ?>