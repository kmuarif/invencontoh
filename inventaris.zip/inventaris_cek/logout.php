<?php 
    session_start();
    unset($_SESSION['username']);
    unset($_SESSION['id_useropd']);
    unset($_SESSION['kode_opd']);
    unset($_SESSION['nip_user']);        
    unset($_SESSION['locking_data_domain']);
    unset($_SESSION['nama_user']);
    unset($_SESSION['akses_level']);
            
    session_destroy();
    header("location:login.php");
 ?>
